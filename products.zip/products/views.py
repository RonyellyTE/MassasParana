from django.shortcuts import render
from .models import Produto, Categoria

def home(request):
    categorias = Categoria.objects.all()
    produtos = Produto.objects.all()
    return render(request, 'products_home.html', {'categorias': categorias, 'produtos': produtos})

def produtos_por_categoria(request, categoria_id):
    categorias = Categoria.objects.all()
    categoria = Categoria.objects.get(id=categoria_id)
    produtos = categoria.produtos.all()  # Produtos da categoria selecionada
    return render(request, 'home.html', {
        'categorias': categorias,
        'produtos': produtos,
        'categoria_selecionada': categoria
    })

